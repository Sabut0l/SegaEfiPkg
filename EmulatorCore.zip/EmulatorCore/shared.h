#ifndef _SHARED_H_
#define _SHARED_H_

#include "UefiLibC.h"

#include "types.h"
#include "osd.h"
#include "macros.h"
#include "loadrom.h"
#include "m68k/m68k.h"
#include "z80/z80.h"
#include "system.h"
#include "genesis.h"
#include "vdp_ctrl.h"
#include "vdp_render.h"
#include "mem68k.h"
#include "memz80.h"
#include "membnk.h"
#include "io_ctrl.h"
#include "input_hw/input.h"
#include "sound/sound.h"
#include "sound/psg.h"
#include "sound/ym2413.h"
#include "sound/ym2612.h"
#ifdef HAVE_YM3438_CORE
#include "sound/ym3438.h"
#endif
#ifdef HAVE_OPLL_CORE
#include "sound/opll.h"
#endif
#include "cart_hw/sram.h"
#include "cart_hw/ggenie.h"
#include "cart_hw/areplay.h"
#include "cart_hw/svp/svp.h"
#include "state.h"

#endif /* _SHARED_H_ */

