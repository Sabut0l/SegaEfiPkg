/* Stub: CD hardware removed from build (NO_CD) */
#include "shared.h"

int scd_context_save(uint8 *state) { return 0; }
int scd_context_load(uint8 *state, char *version) { return 0; }
void scd_update(unsigned int cycles) { }
void scd_end_frame(unsigned int cycles) { }
void scd_reset(int hard_reset) { }
void scd_init(void) { }
