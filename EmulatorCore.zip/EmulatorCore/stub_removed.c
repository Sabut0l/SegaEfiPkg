/* Stubs for removed modules: CD, SVP, SMS, S68K, peripherals */
#include "shared.h"

/* ===== Global variable stubs ===== */
svp_t svp_data;
svp_t *svp = &svp_data;
m68ki_cpu_core s68k;

/* ===== CD Hardware (scd) ===== */
int scd_context_save(uint8 *state) { return 0; }
int scd_context_load(uint8 *state, char *version) { return 0; }
void scd_update(unsigned int cycles) { }
void scd_end_frame(unsigned int cycles) { }
void scd_reset(int hard) { }
void scd_init(void) { }
int scd_68k_irq_ack(int level) { return 0; }
void prg_ram_dma_w(unsigned int length) { }
void word_ram_2M_dma_w(unsigned int length) { }

/* ===== CD Disc (cdd) ===== */
void cdd_init(int samplerate) { }
void cdd_reset(void) { }
int cdd_context_save(uint8 *state) { return 0; }
int cdd_context_load(uint8 *state, char *version) { return 0; }
int cdd_load(char *filename, char *header) { return 0; }
void cdd_unload(void) { }
void cdd_read_data(uint8 *dst, uint8 *subheader) { }
void cdd_seek_audio(int index, int lba) { }
void cdd_read_audio(unsigned int samples) { }
void cdd_update_audio(unsigned int samples) { }
void cdd_update(void) { }
void cdd_process(void) { }

/* ===== CD Controller (cdc) ===== */
void cdc_init(void) { }
void cdc_reset(void) { }
int cdc_context_save(uint8 *state) { return 0; }
int cdc_context_load(uint8 *state) { return 0; }
void cdc_dma_init(void) { }
void cdc_dma_update(unsigned int cycles) { }
void cdc_decoder_update(uint32 header) { }
void cdc_reg_w(unsigned char data) { }
unsigned char cdc_reg_r(void) { return 0; }
unsigned short cdc_host_r(uint8 cpu_access) { return 0; }

/* ===== PCM Sound (pcm) ===== */
void pcm_init(double clock, int rate) { }
void pcm_reset(void) { }
int pcm_context_save(uint8 *state) { return 0; }
int pcm_context_load(uint8 *state) { return 0; }
void pcm_update(unsigned int samples) { }
void pcm_write(unsigned int address, unsigned char data, unsigned int cycles) { }
unsigned char pcm_read(unsigned int address, unsigned int cycles) { return 0; }
void pcm_ram_dma_w(unsigned int length) { }

/* ===== MegaSD ===== */
void megasd_update_cdda(unsigned int samples) { }
void megasd_reset(void) { }
int megasd_context_save(uint8 *state) { return 0; }
int megasd_context_load(uint8 *state) { return 0; }
void megasd_rom_mapper_w(unsigned int address, unsigned int data) { }
void megasd_enhanced_ssf2_mapper_w(unsigned int address, unsigned int data) { }

/* ===== SVP Chip ===== */
void svp_init(void) { }
void svp_reset(void) { }
void ssp1601_run(unsigned int cycles) { }

/* ===== Sub-CPU (s68k) for Mega CD ===== */
void s68k_init(void) { }
void s68k_pulse_reset(void) { }
void s68k_run(unsigned int cycles) { }
int s68k_cycles(void) { return 0; }
void s68k_update_irq(unsigned int mask) { }
void s68k_pulse_halt(void) { }
void s68k_clear_halt(void) { }
void s68k_pulse_wait(unsigned int address, unsigned int write_access) { }
void s68k_clear_wait(void) { }
unsigned int s68k_get_reg(m68k_register_t reg) { return 0; }
void s68k_set_reg(m68k_register_t reg, unsigned int value) { }

/* ===== YM2413 (OPLL) stubs ===== */
void YM2413Init(void) { }
void YM2413ResetChip(void) { }
void YM2413Write(unsigned int a, unsigned int v) { }
unsigned int YM2413Read(void) { return 0; }
void *YM2413GetContextPtr(void) { return NULL; }
unsigned int YM2413GetContextSize(void) { return 0; }
void YM2413Update(int *buffer, int length) { }

/* ===== SMS Cart stubs ===== */
void sms_cart_init(void) { }
void sms_cart_reset(void) { }
void sms_cart_switch(unsigned char mode) { }
int sms_cart_context_save(uint8 *state) { return 0; }
int sms_cart_context_load(uint8 *state) { return 0; }
int sms_cart_region_detect(void) { return 0; }

/* ===== Rare peripheral stubs ===== */
void mouse_reset(void) { }
void mouse_write(unsigned char data, unsigned char mask) { }
unsigned char mouse_read(void) { return 0; }

void lightgun_refresh(void) { }
void lightgun_reset(void) { }
unsigned char phaser_1_read(void) { return 0; }
unsigned char phaser_2_read(void) { return 0; }

void sportspad_reset(void) { }
void sportspad_1_write(unsigned char data, unsigned char mask) { }
void sportspad_2_write(unsigned char data, unsigned char mask) { }
unsigned char sportspad_1_read(void) { return 0; }
unsigned char sportspad_2_read(void) { return 0; }

void teamplayer_init(void) { }
void teamplayer_reset(void) { }
void teamplayer_1_write(unsigned char data, unsigned char mask) { }
void teamplayer_2_write(unsigned char data, unsigned char mask) { }
unsigned char teamplayer_1_read(void) { return 0; }
unsigned char teamplayer_2_read(void) { return 0; }

void activator_reset(void) { }
void activator_1_write(unsigned char data, unsigned char mask) { }
void activator_2_write(unsigned char data, unsigned char mask) { }
unsigned char activator_1_read(void) { return 0; }
unsigned char activator_2_read(void) { return 0; }

void paddle_reset(void) { }
void paddle_1_write(unsigned char data, unsigned char mask) { }
void paddle_2_write(unsigned char data, unsigned char mask) { }
unsigned char paddle_1_read(void) { return 0; }
unsigned char paddle_2_read(void) { return 0; }

void graphic_board_reset(void) { }
void graphic_board_write(unsigned char data, unsigned char mask) { }
unsigned char graphic_board_read(void) { return 0; }

void smash_reset(void) { }
unsigned char smash_1_read(void) { return 0; }
unsigned char smash_2_read(void) { return 0; }

void terebi_oekaki_reset(void) { }

void xe_1ap_reset(void) { }
void xe_1ap_1_write(unsigned char data, unsigned char mask) { }
void xe_1ap_2_write(unsigned char data, unsigned char mask) { }
unsigned char xe_1ap_1_read(void) { return 0; }
unsigned char xe_1ap_2_read(void) { return 0; }

unsigned char justifier_read(void) { return 0; }
void justifier_write(unsigned char data, unsigned char mask) { }
unsigned char menacer_read(void) { return 0; }

/* ===== YX5200 stubs ===== */
void yx5200_init(int samplerate) { }
void yx5200_reset(void) { }
void yx5200_write(unsigned int rx_data) { }
void yx5200_update(unsigned int samples) { }
int yx5200_context_save(uint8 *state) { return 0; }
int yx5200_context_load(uint8 *state) { return 0; }

/* ===== EQ stubs ===== */
void init_3band_state(void *es, int lowfreq, int highfreq, int mixfreq) { }
double do_3band(void *es, int sample) { return (double)sample; }
