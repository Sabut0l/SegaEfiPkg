
#ifndef _TYPES_H_
#define _TYPES_H_

/* UefiLibC.h определяет все типы. 
   types.h просто обеспечивает совместимость. */
#ifndef _UEFI_LIBC_H_
#include "UefiLibC.h"
#endif

typedef union
{
    uint16 w;
    struct
    {
#ifdef LSB_FIRST
        uint8 l;
        uint8 h;
#else
        uint8 h;
        uint8 l;
#endif
    } byte;

} reg16_t;

#endif /* _TYPES_H_ */
